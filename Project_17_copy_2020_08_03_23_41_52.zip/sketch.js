  var ball,img,paddle,soccerball,glasspaddle;
  function preload() {
  ball=loadAnimation("ball.png");
  paddle=loadAnimation("paddle.png");
}
  function setup() {
  createCanvas(400, 400);
   glasspaddle=createSprite(390,200,10,70);
  glasspaddle.addAnimation("paddleimage",paddle); 
  soccerball=createSprite(200,200,12,12);  
  soccerball.addAnimation("soccerball",ball);
  soccerball.scale=0.5;  
  soccerball.velocityX=9; 
    
}

function draw() {
 edges=createEdgeSprites();
  soccerball.bounceOff(edges[0]);
  soccerball.bounceOff(edges[2]);
  soccerball.bounceOff(edges[3]);
  
  
  if(soccerball.bounceOff(glasspaddle)){
  soccerball.y=Math.round(random(0,350));
  soccerball.x=Math.round(random(350,0)); 
}   
  
  background(205,153,0);
 
  
  
  if(keyDown(UP_ARROW)){
  glasspaddle.velocityY=-10;
    
  }
  
  if(keyDown(DOWN_ARROW)){
  glasspaddle.velocityY=10;  
    
  }
  

  
  
  drawSprites();
}

function randomVelocity(){
if(soccerball.isTouching(glasspaddle)){
soccerball.velocityX=random(-10,10);
soccerball.velocityY=random(-7,7);  
}
}